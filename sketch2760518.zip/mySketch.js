// 遊戲狀態與常數
let bubbles = []; // 儲存氣球物件的陣列
let pops = [];    // 儲存爆破粒子物件的陣列
const MAX_BUBBLES = 15; // 螢幕上同時出現的最大氣球數量

// 遊戲與計分變數
let score = 0;
const TARGET_COLOR_HEX = '#ffca3a'; // 黃色氣球的 HEX 代碼 (加分目標)

// 音效變數 (需要啟用 p5.sound 函式庫)
let popOscillator; 

// ===================================
// 輔助函數：繪製星星 (用於氣球反光效果)
// ===================================
function drawStar(x, y, radius1, radius2, npoints) {
  let angle = TWO_PI / npoints;
  let halfAngle = angle / 2.0;
  beginShape();
  for (let a = 0; a < TWO_PI; a += angle) {
    let sx = x + cos(a) * radius2;
    let sy = y + sin(a) * radius2;
    vertex(sx, sy);
    sx = x + cos(a + halfAngle) * radius1;
    sy = y + sin(a + halfAngle) * radius1;
    vertex(sx, sy);
  }
  endShape(CLOSE);
}

// ===================================
// 爆破特效類別 (PopEffect Class)
// 負責處理氣球被點擊後出現的短暫粒子效果
// ===================================
class PopEffect {
    constructor(x, y) {
        this.x = x;
        this.y = y;
        this.size = random(10, 20); 
        this.lifespan = 60; // 粒子的生命週期 (幀數)
        this.alpha = 255;   // 粒子的透明度
        this.vx = random(-1.5, 1.5); // X 軸速度
        this.vy = random(-1.5, 1.5); // Y 軸速度
    }

    update() {
        // 嚴格的安全檢查，防止數據損壞導致運行時錯誤
        if (this.vx === undefined || this.vy === undefined || this.lifespan === undefined) {
            this.lifespan = 0; 
            return;
        }

        this.x += this.vx;
        this.y += this.vy;
        this.lifespan -= 4; 
        // 根據生命週期漸變透明
        this.alpha = map(this.lifespan, 0, 60, 0, 255); 
    }

    show() {
        noStroke();
        fill(255, this.alpha); 
        circle(this.x, this.y, this.size);
    }

    isFinished() {
        return this.lifespan < 0; 
    }
}


// ===================================
// 泡泡類別 (Bubble Class)
// 負責氣球的移動、繪製和重生邏輯
// ===================================
class Bubble {
  constructor(x, y, r) {
    this.x = x;
    this.y = y;
    this.r = r;
    
    // 隨機顏色並儲存 HEX 值，方便與目標顏色比較
    this.colorHex = color(random(100, 255), random(150, 255), random(200, 255), 150).toString('#rrggbb'); 
    
    // 設置加分目標顏色
    if (random() < 0.2) {
        this.colorHex = TARGET_COLOR_HEX; 
    }
    
    let c = color(this.colorHex);
    this.colorR = red(c);
    this.colorG = green(c);
    this.colorB = blue(c);
    
    // 速度與大小成反比 (大氣球慢，小氣球快)
    this.speed = map(this.r, 15, 40, 3, 0.5); 
  }

  move() {
    this.y -= this.speed;           // 向上移動
    this.x += random(-0.5, 0.5);   // 左右輕微飄動
    if (this.y < -this.r) {
        this.respawn(); // 氣球離開視窗頂部時重生
    }
  }
   
  respawn() {
    this.y = height + this.r; // 在視窗底部外重生
    this.x = random(width);
    this.r = random(15, 40);
    
    // 重新隨機顏色
    this.colorHex = color(random(100, 255), random(150, 255), random(200, 255), 150).toString('#rrggbb');
    if (random() < 0.2) {
        this.colorHex = TARGET_COLOR_HEX;
    }
    let c = color(this.colorHex);
    this.colorR = red(c);
    this.colorG = green(c);
    this.colorB = blue(c);
    
    this.speed = map(this.r, 15, 40, 3, 0.5);
  }

  show() {
    // 繪製氣球主體
    fill(this.colorR, this.colorG, this.colorB, 180); 
    stroke(255);
    strokeWeight(2);
    circle(this.x, this.y, this.r * 2);
    
    // 繪製氣球反光 (星星形狀)
    noStroke(); 
    fill(255, 255, 255, 220); 
    
    let starX = this.x - this.r * 0.3; 
    let starY = this.y - this.r * 0.3; 
    
    let radius1 = this.r * 0.08; 
    let radius2 = this.r * 0.18; 
    let npoints = 5;            

    drawStar(starX, starY, radius1, radius2, npoints);
  }
  
  isClicked(mx, my) {
    // 檢查滑鼠點擊是否在氣球範圍內
    let d = dist(mx, my, this.x, this.y);
    return d < this.r; 
  }
}


// -----------------------------------
// 輔助函數：創建一個新泡泡並加入陣列
// -----------------------------------
function createNewBubble(startY = height + 50) {
    let x = random(width);
    let r = random(15, 40);
    
    let b = new Bubble(x, startY, r);
    bubbles.push(b);
}

// ===================================
// P5.JS 核心函式
// ===================================

function setup() {
  createCanvas(600, 400); // 創建繪圖畫布
  angleMode(RADIANS); 
  
  // 音效初始化 
  // **修正重點：增加檢查以確保 p5.Oscillator 存在，防止 p5.sound 庫未載入時崩潰 (解決錯誤173的潛在原因)**
  if (typeof p5.Oscillator !== 'undefined') {
    popOscillator = new p5.Oscillator('triangle'); 
    popOscillator.amp(0); 
    popOscillator.start(); 
  } else {
    popOscillator = null; // 設為 null 以確保 mousePressed 中的檢查能正常運作
    console.warn("P5.sound library is missing. Sound effects disabled.");
  }

  // 初始化氣球陣列
  for (let i = 0; i < MAX_BUBBLES; i++) {
    createNewBubble(random(height)); // 將氣球分散在畫面高度上
  }
}

// 點擊滑鼠時觸發計分與爆破
function mousePressed() {
    // 啟用瀏覽器的音訊內容
    // **修正重點：只有在 popOscillator 成功初始化時才嘗試啟動音訊**
    if (popOscillator && typeof userStartAudio === 'function') {
        userStartAudio(); 
    }
    
    // 從後往前遍歷氣球，確保點擊到最上層的氣球
    for (let i = bubbles.length - 1; i >= 0; i--) {
        let b = bubbles[i];
        
        if (b.isClicked(mouseX, mouseY)) {
            
            // 1. 計分邏輯
            if (b.colorHex === TARGET_COLOR_HEX) {
                score += 1; // 黃色氣球加分
            } else {
                score -= 1; // 其他顏色氣球扣分
            }
            
            // 2. 爆破音效
            // **修正重點：確保 popOscillator 存在且功能可用**
            if (popOscillator && typeof popOscillator.freq === 'function') {
                popOscillator.freq(random(300, 700)); 
                popOscillator.amp(0.3, 0.01);
                popOscillator.amp(0, 0.2, 0.05);
            }
            
            // 3. 視覺爆破特效
            for (let j = 0; j < 5; j++) {
                let p = new PopEffect(b.x, b.y); 
                pops.push(p);
            }
            
            // 4. 氣球重生
            b.respawn(); 
            
            break; // 點擊一個氣球後就退出迴圈
        }
    }
}


function draw() {
  background(255, 250, 205); // 淺黃色背景 (原為深藍色)
  
  // 1. 更新並繪製氣球
  for (let i = 0; i < bubbles.length; i++) { 
        let b = bubbles[i];
        
        b.move();
        b.show();
  }
  
  // 2. 處理爆破特效 (使用 filter 進行穩定更新和清理)
  pops = pops.filter(p => {
        // 【最終穩定修復】: 確保物件存在且具備所需的函式
        if (!p || typeof p.update !== 'function' || typeof p.show !== 'function') {
            return false; // 如果無效，則從陣列中移除
        }

        // 更新粒子狀態 (移動、減少生命週期)
        p.update();
        
        // 繪製粒子
        p.show();
        
        // 只保留未結束的粒子 (p.isFinished() 回傳 true 表示已結束)
        return !p.isFinished();
  });


  // 3. 顯示文字和分數的介面
  textSize(32);
  
  // 分數文字顏色 (橘紅色)
  fill(235, 100, 36); 

  // 左上角顯示固定文字 (學號)
  const LEFT_TEXT = '414730282';
  textAlign(LEFT, TOP); 
  text(LEFT_TEXT, 10, 10); 

  // 右上角顯示分數
  const RIGHT_TEXT = `得分: ${score}`;
  textAlign(RIGHT, TOP); 
  text(RIGHT_TEXT, width - 10, 10); 
}
